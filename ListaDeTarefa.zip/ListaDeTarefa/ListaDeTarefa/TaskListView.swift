import SwiftUI

struct Task: Identifiable {
    var id = UUID()
    var title: String
    var isCompleted: Bool
}

struct TaskListView: View {
    @State private var tasks: [Task] = [
        Task(title: "Fazer um churras", isCompleted: false),
        Task(title: "Lavar o cachorro", isCompleted: true),
        Task(title: "Estudar Física", isCompleted: false)
    ]

    var body: some View {
        NavigationView {
            List {
                ForEach(tasks) { task in
                    TaskRowView(task: task) {
                        toggleTaskCompletion(task: task)
                    }
                }
            }
            .navigationBarTitle("Lista de Tarefas")
        }
    }

    func toggleTaskCompletion(task: Task) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index].isCompleted.toggle()
        }
    }
}

struct TaskRowView: View {
    var task: Task
    var toggleTaskCompletion: () -> Void

    var body: some View {
        HStack {
            Text(task.title)
            
            Spacer()
            
            Button(action: {
                toggleTaskCompletion()
            }) {
                Image(systemName: task.isCompleted ? "circle.fill" : "circle")
                    .foregroundColor(task.isCompleted ? .black : .gray)
            }
        }
    }
}

@main
struct TaskListViewApp: App {
    var body: some Scene {
        WindowGroup {
            TaskListView()
        }
    }
}
struct TaskListView_Previews: PreviewProvider {
    static var previews: some View {
        TaskListView()
    }
}

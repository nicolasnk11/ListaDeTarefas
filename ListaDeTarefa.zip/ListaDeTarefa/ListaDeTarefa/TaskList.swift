//
//  TaskList.swift
//  ListaDeTarefa
//
//  Created by User on 22/09/23.
//

import SwiftUI

struct TaskList: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    TaskList()
}
